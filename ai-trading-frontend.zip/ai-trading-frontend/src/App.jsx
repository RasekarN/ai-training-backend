import React, { useState } from "react";
import ChartBox from "./components/ChartBox";
import SignalForm from "./components/SignalForm";
import SignalResult from "./components/SignalResult";

export default function App() {
  // ------------------------------------------------
  // State
  // ------------------------------------------------
  const [selectedSymbol, setSelectedSymbol] = useState("NIFTY");
  const [selectedTimeframe, setSelectedTimeframe] = useState("1D");
  const [ohlcData, setOhlcData] = useState([]);
  const [signalResult, setSignalResult] = useState(null);

  // ------------------------------------------------
  // Backend API call
  // ------------------------------------------------
  const runPrediction = async () => {
    setSignalResult(null);

    try {
      const response = await fetch("http://localhost:8000/tv-webhook", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: selectedSymbol,
          timeframe: selectedTimeframe,
        }),
      });

      const data = await response.json();

      // Store prediction result
      setSignalResult(data);

      // Convert backend OHLC → lightweight-charts format
      if (data.ohlc) {
        const formatted = data.ohlc.map((c) => ({
          time: c.time,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
        }));
        setOhlcData(formatted);
      }
    } catch (err) {
      console.error("Prediction error:", err);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>AI Trading Engine</h1>

      {/* -------------------- FORM ---------------------- */}
      <div style={{ display: "flex", gap: "20px", marginBottom: "20px" }}>
        <div>
          <label>Index / Commodity </label>
          <select
            value={selectedSymbol}
            onChange={(e) => setSelectedSymbol(e.target.value)}
          >
            <option value="NIFTY">NIFTY</option>
            <option value="BANKNIFTY">BANKNIFTY</option>
            <option value="CRUDE">CRUDE</option>
            <option value="NG">NATURAL GAS</option>
          </select>
        </div>

        <div>
          <label>Timeframe </label>
          <select
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
          >
            <option value="1D">1 Day</option>
            <option value="1H">1 Hour</option>
            <option value="15m">15 Minutes</option>
            <option value="5m">5 Minutes</option>
          </select>
        </div>

        <button onClick={runPrediction}>Run Prediction</button>
      </div>

      {/* -------------------- CHART ---------------------- */}
      <h2>Dashboard</h2>
      <ChartBox symbol={selectedSymbol} ohlc={ohlcData} />

      {/* -------------------- AI RESULT ------------------ */}
      <h2 style={{ marginTop: "30px" }}>AI Prediction</h2>
      <SignalResult data={signalResult} />

      {/* ---------------- TRAINING MONITOR --------------- */}
      <h2 style={{ marginTop: "30px" }}>Training Monitor</h2>
      <p>Model training logs will appear here soon…</p>
    </div>
  );
}
